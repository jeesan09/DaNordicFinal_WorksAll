<template>
  <v-dialog max-width="600px"
             v-model="dialog">
  
      <v-btn flat slot="activator">
         <v-icon >edit</v-icon>

      </v-btn>


    <v-card>
              <v-toolbar dark  color="teal lighten-3" class="mb-5">
                <v-toolbar-title>Assaign Role  </v-toolbar-title>
                <v-spacer></v-spacer>
              </v-toolbar>
              

               <v-form  ref="form" class=px-3>
                         <v-select
                          :items="items"
                          label="Roles"
                          v-model="selectedRole"
                         ></v-select>

              


                  <v-card-actions class=py-5>
                    <v-btn left dark color="teal lighten-3" v-on:click="editData" :loading="loader">Assaign</v-btn>
                   <v-spacer />
                   
                  </v-card-actions>                 
                </v-form>

    </v-card>
  </v-dialog>
</template>

<script>
import axios from 'axios'

export default {

  props:{

    user_id:"",
    cll_parent:""




  },

  data() {


    return {
      
       items: ['user', 'admin', 'superAdmin'],
       selectedRole:'',
       dialog: false,
       loader:false

    }
  },

  methods:{


    editData(){

        var xa= '';
        xa = localStorage.getItem("VueToken");
        console.log(xa);

const axiosParams = {
  headers: {
    'Content-Type': 'application/json',
    'Authorization':"Bearer "+xa,
  }
};

         this.loader=true;

         axios.put(`http://localhost:8000/api/user/${this.user_id}`,{

          type:this.selectedRole
      



          },axiosParams).then((response) => {

           // console.log(response.data.email);

           this.loader=false;
              
              console.log(response.data);

              if(response.data=='not Super Admin'){

                this.loader=false;
                this.$swal.fire({
                type: 'error',
                title: 'Only Super Admin can Assaign Role',
               

                footer: 'Unauthorized'
                })

              


        
              }

              else{
                 this.loader=false;
                this.$swal({
                  position: 'bottom-middle',
                  type: 'success',
                  title: 'Successfully Role Assaigned',
                  showConfirmButton: false,
                  timer: 2000
                  }).then(() =>{
                     this.afterRegistation();
                 })
            
          //  this.afterRegistation();

              }

          }, (error) => {
               this.loader=false;
                this.$swal.fire({
                type: 'error',
                title: 'Oops...',
                text: error,

                footer: 'Something went Wrong!'
                })

           })






     },


          afterRegistation(){
            

            //  
      
                this.dialog = false;
                //this.$router.go(0);
                this.cll_parent();
               console.log('succes');
   

          }     



  }


}
</script>

<style>


</style>