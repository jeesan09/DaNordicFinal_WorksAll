<template>

<nav>  
    <v-toolbar
      
      color="teal lighten-3"
      dark
      id="header_blogin"
      
    >
      <v-toolbar-side-icon @click="drawer=!drawer"></v-toolbar-side-icon>

      
      <v-spacer></v-spacer>
              
          <v-text-field
           
            style="max-width:180px;"

          ></v-text-field>
      

      <v-btn icon>

        <v-icon>search</v-icon>
      </v-btn>

      <v-btn flat  @click="singOut" :loading="loader">
        <span>Sing Out</span>
        <v-icon right>exit_to_app</v-icon>
      </v-btn>

      
    </v-toolbar>





<v-navigation-drawer   app   v-model="drawer"  class="grey lighten-2">


      <v-list>
      <v-list-tile>
        <v-list-tile-action>
          <v-icon>home</v-icon>
        </v-list-tile-action>
        <v-list-tile-title>Home</v-list-tile-title>
      </v-list-tile>

      <v-list-group
        prepend-icon="account_circle"
        value="true"
      >
        <template v-slot:activator>
          <v-list-tile>
            <v-list-tile-title>Users</v-list-tile-title>
          </v-list-tile>
        </template>


        <v-list-group
          sub-group
          no-action
          value="true"

        >
          <template v-slot:activator>
            <v-list-tile>
              <v-list-tile-title>Filters</v-list-tile-title>
            </v-list-tile>
          </template>


         <v-list-tile
            @click="Super_Admin"
         >

              <v-list-tile-title >Super Admin</v-list-tile-title>
            
              <i class="fas fa-user-secret fa-lg" style="margin-right:30px; width:20px; opacity: 0.5;"></i>
          
           
         </v-list-tile>  

         <v-list-tile
             @click="Admin"
         >

              <v-list-tile-title >Admin</v-list-tile-title>
            
             
            
              <i class="fas fa-user-shield fa-lg" style="margin-right:30px; width:20px; opacity: 0.5;"></i>
           
         </v-list-tile>

         <v-list-tile
             @click="User"

         >

              <v-list-tile-title >User</v-list-tile-title>
            
              <i class="fas fa-user-tie fa-lg"  style="margin-right:30px; width:20px; opacity: 0.5;"></i>
          
           
         </v-list-tile>

         <v-list-tile
             @click="All"
         >

              <v-list-tile-title >All</v-list-tile-title>
            
              <i class="fas fa-users fa-lg" style="margin-right:30px; width:20px; opacity: 0.5;"></i>
          
           
         </v-list-tile>



        </v-list-group>

        <v-list-group
          no-action
          sub-group
       
        >
          <template v-slot:activator>
            <v-list-tile>
              <v-list-tile-title>Admin</v-list-tile-title>
            </v-list-tile>
          </template>

          <v-list-tile
            v-for="(admin, i) in admins"
            :key="i"
            @click=""
            
          >
            <v-list-tile-title v-text="admin[0]"></v-list-tile-title>
            <v-list-tile-action>
              <v-icon v-text="admin[1]"></v-icon>
            </v-list-tile-action>
          </v-list-tile>
        </v-list-group>




      </v-list-group>
    </v-list>
   
</v-navigation-drawer>



</nav>
</template>



<script>

  import UserEdit from './UserEdit.vue'
  import axios from 'axios'




  export default {

    components: {
     
    
      UserEdit
    },

  props:{

    admin:"",
    superAdmin:"",
    user:"",
    all:""




  },

    data (){

      return {

            admins: [
              ['User Log', 'people_outline'],
              ['Settings', 'settings']
            ],


            drawer:true,
            loader:false




      }
   },
  


  created() {

// this close the drawer for small devices      
      if(window.innerWidth<500){

         this.drawer = false;
      }

  },


  methods: {



  singOut(){

this.loader=true;  

var x= '';
x = localStorage.getItem("VueToken");

axios.post(`http://localhost:8000/api/auth/logout?token=${x}`,{








        }).then((response) => {

         
              localStorage.clear();

              

              this.logOut();

         this.loader=false;  

                       
         }, (error) => {
               

                     this.loader=false;
                       this.$swal.fire({
                        type: 'error',
                        title: 'Attention!',
                        text: 'our server is Temporay Down.Plese try later',
                        showConfirmButton: true,
                       
                        
                        })





               localStorage.clear();

         })











          },

          logOut(){

            this.$swal({
            position: 'bottom-middle',
            type: 'success',
            title: 'Successfully Logged out',
            showConfirmButton: false,
            timer: 2000
            }).then(() =>{
               this.$router.push('/');
           })


          },


          Admin(){


      
             this.admin();

                   if(window.innerWidth<500){

                        this.drawer=!this.drawer; 
                    }
      
          },

          Super_Admin(){


       
             this.superAdmin();

                   if(window.innerWidth<500){

                        this.drawer=!this.drawer; 
                    }


          },

          User(){

             this.user();

                   if(window.innerWidth<500){

                        this.drawer=!this.drawer; 
                    }


          },

          All(){

           this.all();

                   if(window.innerWidth<500){

                        this.drawer=!this.drawer; 
                    }

          }

    }
    
  }


</script>

<style>

 #side_bar{

    height: 100%;
 }

</style>